"""Strict models for the safe Endpoint Platform service API."""

from __future__ import annotations

from datetime import datetime
import re
from typing import Annotated, Literal, TypeAlias
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from ._contracts import (
    BaselineSectionsV1,
    ContextWarningCodeV1,
    DeviceContextDiffV1,
    HealthSectionsV1,
    InventorySectionsV1,
    NetworkSectionsV1,
    SessionSectionsV1,
)


SafeContextProfile: TypeAlias = Literal["baseline_v1", "health_v1", "network_v1", "inventory_v1", "session_v1"]
_SAFE_PROFILES = frozenset(("baseline_v1", "health_v1", "network_v1", "inventory_v1", "session_v1"))


class SafeModel(BaseModel):
    """Reject fields outside the service's explicitly safe projections."""

    model_config = ConfigDict(extra="forbid")


class Device(SafeModel):
    id: UUID
    device_identifier: str = Field(min_length=1, max_length=256)
    display_name: str = Field(min_length=1, max_length=256)
    retired_at: datetime | None
    last_seen_at: datetime | None
    online: bool = False


class AgentNetworkProfile(SafeModel):
    """One currently available safe Context profile for a network identity."""

    profile: SafeContextProfile
    collected_at: datetime


class AgentNetworkIdentity(SafeModel):
    """Safe service-to-service identity material for exact MAC correlation."""

    id: UUID
    device_identifier: str = Field(min_length=1, max_length=256)
    display_name: str = Field(min_length=1, max_length=256)
    last_seen_at: datetime | None
    online: bool = False
    baseline_collected_at: datetime
    profiles: list[AgentNetworkProfile] = Field(max_length=5)
    baseline_mac_keys: list[Annotated[str, Field(pattern=r"^mac-[0-9a-f]{12}$")]] = Field(
        min_length=1, max_length=64
    )

    @field_validator("baseline_mac_keys")
    @classmethod
    def canonical_baseline_mac_keys(cls, value: list[str]) -> list[str]:
        if value != sorted(set(value)) or any(
            re.fullmatch(r"mac-[0-9a-f]{12}", key) is None for key in value
        ):
            raise ValueError("baseline MAC keys must be canonical")
        return value


class AgentNetworkIdentityPage(SafeModel):
    """One bounded page from the Endpoint Platform identity feed."""

    data: list[AgentNetworkIdentity] = Field(max_length=250)
    next_cursor: UUID | None


class ContextProfileAvailability(SafeModel):
    profile: SafeContextProfile
    status: str = Field(min_length=1, max_length=32)
    last_collected_at: datetime | None


class ContextSnapshot(SafeModel):
    id: UUID
    profile: SafeContextProfile
    collected_at: datetime
    semantic_hash: str | None = Field(default=None, pattern=r"^[a-f0-9]{64}$")
    warnings: list[ContextWarningCodeV1] = Field(default_factory=list, max_length=16)
    sections: BaselineSectionsV1 | HealthSectionsV1 | NetworkSectionsV1 | InventorySectionsV1 | SessionSectionsV1

    @field_validator("sections", mode="before")
    @classmethod
    def validate_profile_sections(cls, value: object, info: object) -> object:
        profile = getattr(info, "data", {}).get("profile")
        models = {
            "baseline_v1": BaselineSectionsV1,
            "health_v1": HealthSectionsV1,
            "network_v1": NetworkSectionsV1,
            "inventory_v1": InventorySectionsV1,
            "session_v1": SessionSectionsV1,
        }
        model = models.get(profile)
        return value if model is None else model.model_validate(value)

    @model_validator(mode="after")
    def validate_profile_section_pair(self) -> "ContextSnapshot":
        expected = {
            "baseline_v1": BaselineSectionsV1,
            "health_v1": HealthSectionsV1,
            "network_v1": NetworkSectionsV1,
            "inventory_v1": InventorySectionsV1,
            "session_v1": SessionSectionsV1,
        }[self.profile]
        if not isinstance(self.sections, expected):
            raise ValueError("context sections do not match profile")
        return self


class DeviceContext(SafeModel):
    device: Device
    profiles: list[ContextProfileAvailability]
    snapshots: list[ContextSnapshot]


class BaselineHistory(SafeModel):
    """Bounded, newest-first baseline snapshots for one device."""

    snapshots: list[ContextSnapshot] = Field(max_length=100)

    @model_validator(mode="after")
    def validate_baseline_only(self) -> "BaselineHistory":
        if any(snapshot.profile != "baseline_v1" for snapshot in self.snapshots):
            raise ValueError("baseline history includes a non-baseline snapshot")
        return self


class InventoryContext(ContextSnapshot):
    """Typed current or historical physical inventory observation."""

    profile: Literal["inventory_v1"]
    sections: InventorySectionsV1


class SessionContext(ContextSnapshot):
    """Typed current dynamic interactive-session observation."""

    profile: Literal["session_v1"]
    sections: SessionSectionsV1


class InventoryHistory(SafeModel):
    """Bounded, newest-first physical inventory snapshots."""

    snapshots: list[ContextSnapshot] = Field(max_length=100)

    @model_validator(mode="after")
    def validate_inventory_only(self) -> "InventoryHistory":
        if any(snapshot.profile != "inventory_v1" for snapshot in self.snapshots):
            raise ValueError("inventory history includes a non-inventory snapshot")
        return self


class Collection(SafeModel):
    id: UUID
    device_id: UUID
    profile: SafeContextProfile
    status: str = Field(min_length=1, max_length=32)
    requested_at: datetime
    result_received_at: datetime | None
    completed_at: datetime | None
    failure_code: str | None = Field(default=None, max_length=128)


class CollectionDetails(SafeModel):
    collection: Collection
    snapshot: ContextSnapshot | None


class ContextComparison(SafeModel):
    """Typed wrapper around the fixed-code baseline comparison contract."""

    comparison: DeviceContextDiffV1


def is_safe_profile(value: object) -> bool:
    """Return whether a runtime value can cross the public SDK profile boundary."""

    return isinstance(value, str) and value in _SAFE_PROFILES
